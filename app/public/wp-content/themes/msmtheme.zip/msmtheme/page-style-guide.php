<?php
/**
 * Template Name: Style Guide
 */

 get_template_part(THEME_HEADER);  ?>



<div class="container py-5 style-guide">
    <h1>Guía de Estilos</h1>

    <!-- Tipografía -->
    <section>
        <h2>Tipografía Encabezados</h2>
        
        <div class="mb-4">
            <h1>Encabezado H1</h1>
            <h2>Encabezado H2</h2>
            <h3>Encabezado H3</h3>
            <h4>Encabezado H4</h4>
            <h5>Encabezado H5</h5>
            <h6>Encabezado H6</h6>
        </div>

        <div class="msm-breadcrumb d-block d-sm-row">
            <a class="msm-breadcrumb-item-first" href="http://msm-dev.local">Home /</a><a class="msm-breadcrumb-item" href="http://msm-dev.local/prensa"> Prensa /</a><span class="msm-breadcrumb msm-breadcrumb-item-last">Ojos en Alerta llegó a un nuevo municipio de Córdoba</span>
        </div>
        
        <h1 class="post-title">Ojos en Alerta llegó a un nuevo municipio de Córdoba</h1>

        <h5 class="post-resume">
            <p>Ya hay 44 distritos en 9 provincias del país adheridos a esta herramienta de seguridad originada en San Miguel. El intendente de San Miguel, Jaime Méndez, firmó ayer un convenio con el jefe comunal de Sampacho (Córdoba), Franco Suárez, para implementar Ojos en Alerta en su distrito. Se trata de un programa originado en San […]</p>
        </h5>
        <div class="post-content">
            <p>Este es un párrafo de texto normal. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
            <p>Este es otro párrafo de texto. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        </div>
    </section>

    <!-- Botones -->
    <section>
        <h2>Botones</h2>
        
        <div class="button-group">
            <h3>Botones 'msm-button'</h3>
            <button class="msm-button">Botón Primario</button>
            <button class="msm-button" disabled>Botón Deshabilitado</button>
        </div>
        
        <div class="button-group">
            <h3>Botones de Acción msm</h3>
            <button class="btn-licencias">Botón de Acción</button>
            <button class="btn-capacitate-download">Botón de Descarga</button>
        </div>
        <div class="button-group">
            <h3>Bootstrap buttons</h3>
            <button type="button" class="btn btn-primary">Primary</button>
            <button type="button" class="btn btn-secondary">Secondary</button>
            <button class="btn btn-outline-primary">Outlined</button>
            <button class="btn btn-outlimed-primary" disabled>Outlined Deshabilitado</button>
        </div>

        <div class="button-group">
            <h4>Bootstrap buttons 'sm'</h4>
            <button type="button" class="btn btn-primary btn-sm">Primary</button>
            <button type="button" class="btn btn-secondary btn-sm">Secondary</button>
            <button class="btn btn-outline-primary btn-sm">Outlined</button>
            <button class="btn btn-outlimed-primary btn-sm" disabled>Deshabilitado</button>
        </div>


    </section>

    <!-- Colores -->
    <section>
        <h2>Paleta de Colores</h2>
        
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="msm-text-b color-box">
                    <h3>Azul Institucional</h3>
                    <p>--blue-msm: #1ea5d9</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="color-box">
                    <div>
                        <h3>Azul Oscuro</h3>
                        <p>--blue-msm-600: #0f6a95</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="color-box">
                    <div>
                        <h3>Gris</h3>
                        <p>--msm-gray: #717075</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Enlaces -->
    <section>
        <h2>Links</h2>
        
        <div class="link-group">
            <a href="#">Link Normal</a>
            <a href="#" style="color: var(--blue-msm-400);">Link Azul</a>
            <a href="#" style="color: var(--msm-gray);">Link Gris</a>
        </div>
    </section>
</div>

<?php get_footer(); ?> 